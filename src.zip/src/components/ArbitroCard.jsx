import React from 'react';
// Íconos SVG simples para evitar dependencias externas.

/**
 * Componente para mostrar la información de un árbitro en formato de tarjeta.
 * @param {object} arbitro - Los datos del árbitro.
 * @param {function} onView - Función para ver detalles.
 * @param {function} onEdit - Función para editar.
 * @param {function} onDelete - Función para eliminar.
 */
const ArbitroCard = ({ arbitro, onView, onEdit, onDelete }) => {
    const { id, nombre, codigo, categoria, partidos, activo } = arbitro;
    
    // Clases para el estado ACTIVO/INACTIVO (usa Tailwind CSS)
    const estadoClass = activo 
        ? "bg-green-500 text-white" 
        : "bg-red-500 text-white";

    return (
        <div className="border border-gray-200 rounded-xl shadow-lg p-4 flex flex-col items-center text-center transition-transform transform hover:scale-[1.02] bg-white">
            
            {/* Imagen/Placeholder del Árbitro */}
            <div className="rounded-full bg-gray-100 w-24 h-24 mb-3 flex items-center justify-center border-4 border-blue-400">
                <svg className="w-14 h-14 text-gray-500" fill="currentColor" viewBox="0 0 24 24">
                    {/* Icono de usuario simple (Placeholder) */}
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
            </div>
            
            <h3 className="text-xl font-extrabold text-gray-800">{nombre}</h3>
            <p className="text-sm text-gray-500 mb-2 font-mono">Cód. {codigo || 'N/A'}</p>
            
            <div className="flex justify-center items-center my-1 text-base text-gray-600 font-medium">
                <span className="text-blue-600">{categoria}</span>
                <span className="mx-3 text-gray-400">•</span>
                <span><span className="font-bold text-gray-800">{partidos || 0}</span> Partidos</span>
            </div>
            
            {/* Estado Activo / Inactivo */}
            <div className={`w-full py-1 rounded-full text-xs font-extrabold tracking-wider ${estadoClass} my-3 uppercase`}>
                {activo ? 'ACTIVO' : 'INACTIVO'}
            </div>
            
            {/* Botones de Acción */}
            <div className="flex space-x-3 pt-2 border-t w-full justify-around">
                <button 
                    onClick={() => onView(id)} 
                    title="Ver Detalle" 
                    className="p-2 border border-blue-100 rounded-full text-blue-600 hover:bg-blue-50 transition duration-150 shadow-sm"
                >
                    {/* Icono de Ver (Documento) */}
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </button>
                <button 
                    onClick={() => onEdit(id)} 
                    title="Editar" 
                    className="p-2 border border-green-100 rounded-full text-green-600 hover:bg-green-50 transition duration-150 shadow-sm"
                >
                    {/* Icono de Editar (Lápiz) */}
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                </button>
                <button 
                    onClick={() => onDelete(id)} 
                    title="Eliminar" 
                    className="p-2 border border-red-100 rounded-full text-red-600 hover:bg-red-50 transition duration-150 shadow-sm"
                >
                    {/* Icono de Eliminar (Basura) */}
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                </button>
            </div>
        </div>
    );
};

export default ArbitroCard;
