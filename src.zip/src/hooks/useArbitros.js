import { useState, useEffect } from 'react';
// Asegúrate de que esta ruta a tu configuración de Firebase es correcta
import { db } from '../firebase/firebaseConfig'; 
import { collection, getDocs } from 'firebase/firestore';

/**
 * Hook personalizado para obtener la lista de árbitros de Firebase.
 * Usa un useEffect para cargar los datos solo una vez al montar.
 * @returns {object} { arbitros, loading, error }
 */
export const useArbitros = () => {
    const [arbitros, setArbitros] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        // Función de fetch encapsulada dentro del efecto
        const fetchArbitros = async () => {
            setLoading(true); // Asegurar que el estado de carga se active
            try {
                // Usamos la instancia 'db' importada
                // Asumiendo que la colección se llama 'arbitros'
                const arbitrosRef = collection(db, 'arbitros'); 
                const snapshot = await getDocs(arbitrosRef);
                
                const arbitrosData = snapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                }));
                
                setArbitros(arbitrosData);
                setError(null);

            } catch (err) {
                console.error("Error al obtener árbitros:", err);
                // Ignoramos errores de inicialización de Firebase en modo estricto
                if (!err.message.includes('already exists')) {
                    setError("No se pudieron cargar los árbitros. Verifique la colección.");
                }
            } finally {
                setLoading(false);
            }
        };

        fetchArbitros();

    }, []); // Dependencia vacía para ejecutar una sola vez

    return { arbitros, loading, error };
};
