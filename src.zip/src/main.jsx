import React from "react";
import ReactDOM from "react-dom/client";
import './index.css'
import App from './App.jsx'
import { AuthProvider } from "./context/AuthContext";

ReactDOM.createRoot(document.getElementById("root")).render(
  // <React.StrictMode> <-- ¡Comentamos el Modo Estricto para evitar la doble ejecución!
    <AuthProvider>
      <App />
    </AuthProvider>
  // </React.StrictMode>
);
