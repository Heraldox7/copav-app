export default function DashboardUser() {
  return (
    <div className="text-center text-2xl font-semibold text-[#0C2D82]">
      🏐 Dashboard User del Árbitro (en construcción)
    </div>
  );
}
