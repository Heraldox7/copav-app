import React, { useState } from 'react';
import AdminLayout from '../../layouts/AdminLayout'; // Asegúrate de que esta ruta es correcta
import ArbitroCard from '../../components/ArbitroCard'; // Asegúrate de que esta ruta es correcta
import { useArbitros } from '../../hooks/useArbitros'; 

const ArbitrosAdmin = () => {
    // 1. Obtener datos y estados del hook
    const { arbitros, loading, error } = useArbitros(); 
    
    // 2. Estados para la búsqueda y el filtrado
    const [searchTerm, setSearchTerm] = useState('');
    const [filterCategory, setFilterCategory] = useState('');
    
    // 3. Funciones de CRUD (usando una caja de mensaje personalizada en lugar de alert/confirm)
    // Nota: Necesitarás implementar un Modal o un sistema de notificación propio, 
    // ya que alert/confirm no funcionan bien en entornos en línea.
    const handleAction = (message) => {
        console.log(`[ACTION PENDING] ${message}`);
        // Aquí se mostraría un modal de tu diseño
        alert(message); // Temporalmente, usa alert para confirmar la acción
    };

    const handleAddArbitro = () => handleAction("PENDIENTE: Abrir formulario para Agregar Árbitro.");
    const handleViewArbitro = (id) => handleAction(`PENDIENTE: Mostrar Detalles del árbitro ID: ${id}`);
    const handleEditArbitro = (id) => handleAction(`PENDIENTE: Abrir formulario para Editar Árbitro ID: ${id}`);
    const handleDeleteArbitro = (id) => {
        if (window.confirm(`¿Estás seguro de ELIMINAR al árbitro ID: ${id}? Esta acción no se puede deshacer.`)) {
            handleAction(`PENDIENTE: Lógica de eliminación para árbitro ID: ${id}`);
        }
    };

    // 4. Filtrado de la lista
    const filteredArbitros = arbitros.filter(arbitro => {
        const nombre = arbitro.nombre ? arbitro.nombre.toLowerCase() : '';
        const categoria = arbitro.categoria || '';

        const matchesSearch = nombre.includes(searchTerm.toLowerCase());
        const matchesCategory = filterCategory === '' || categoria === filterCategory;
        
        return matchesSearch && matchesCategory;
    });

    // 5. Manejo de estados de carga y error
    if (loading) {
        return <AdminLayout><div className="p-8 text-center text-gray-500 text-xl">Cargando árbitros, por favor espera...</div></AdminLayout>;
    }

    if (error) {
        return <AdminLayout><div className="p-8 text-center text-red-600 font-bold text-xl">Error al cargar datos: {error}</div></AdminLayout>;
    }


    return (
        <AdminLayout>
            <div className="p-6 md:p-8 bg-gray-50 min-h-screen">
                <h1 className="text-3xl font-extrabold text-gray-800 mb-6 border-b pb-2">
                    Gestión de Árbitros ({filteredArbitros.length} encontrados)
                </h1>
                
                {/* Controles Superiores (Busqueda, Categoria, Agregar) */}
                <div className="flex flex-col md:flex-row justify-between items-center mb-6 space-y-3 md:space-y-0 md:space-x-4 p-4 bg-white rounded-lg shadow-md">
                    
                    <input
                        type="text"
                        placeholder="Buscar árbitro por nombre..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="border border-gray-300 p-2 rounded-lg w-full md:w-80 shadow-inner focus:ring-blue-500 focus:border-blue-500 transition"
                    />
                    
                    <select
                        value={filterCategory}
                        onChange={(e) => setFilterCategory(e.target.value)}
                        className="border border-gray-300 p-2 rounded-lg w-full md:w-48 shadow-inner focus:ring-blue-500 focus:border-blue-500 transition"
                    >
                        <option value="">Todas las Categorías</option>
                        {/* Categorías de ejemplo */}
                        <option value="1ra. Categoría">1ra. Categoría</option>
                        <option value="2da. Categoría">2da. Categoría</option>
                        <option value="3ra. Categoría">3ra. Categoría</option>
                    </select>

                    <button 
                        onClick={handleAddArbitro} 
                        className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg font-bold w-full md:w-auto transition duration-150 shadow-lg hover:shadow-xl transform hover:scale-[1.01]"
                    >
                        + Agregar Nuevo Árbitro
                    </button>
                </div>
                
                {/* Grid de Árbitros */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredArbitros.length > 0 ? (
                        filteredArbitros.map(arbitro => (
                            <ArbitroCard 
                                key={arbitro.id} 
                                arbitro={arbitro} 
                                onView={handleViewArbitro}
                                onEdit={handleEditArbitro}
                                onDelete={handleDeleteArbitro}
                            />
                        ))
                    ) : (
                        <div className="col-span-full text-center p-10 bg-white rounded-lg border-2 border-dashed border-gray-300 shadow-inner">
                            <p className="text-xl text-gray-500 font-semibold">
                                Sin resultados. Ajusta los filtros o <span className='text-blue-600 cursor-pointer' onClick={handleAddArbitro}>agrega un nuevo árbitro.</span>
                            </p>
                        </div>
                    )}
                </div>

                {/* Botones de Exportación */}
                <div className="flex justify-end mt-8 space-x-4">
                    <button className="border border-gray-300 text-gray-700 p-2.5 rounded-lg hover:bg-gray-200 transition font-semibold shadow-md">
                        Exportar Excel
                    </button>
                    <button className="bg-red-600 hover:bg-red-700 text-white p-2.5 rounded-lg transition font-semibold shadow-md">
                        Generar PDF de Reporte
                    </button>
                </div>
            </div>
        </AdminLayout>
    );
};

// Exportación por defecto necesaria para el router
export default ArbitrosAdmin;
