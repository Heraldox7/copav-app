const Partidos = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Gestión de Partidos</h1>
      <p className="text-gray-600">Lista de partidos, resultados y asignaciones de árbitros.</p>
    </div>
  );
};

export default Partidos;
