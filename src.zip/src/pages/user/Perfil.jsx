const Perfil = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Mi Perfil</h1>
      <p className="text-gray-600">Edita tu información personal y credenciales.</p>
    </div>
  );
};

export default Perfil;
