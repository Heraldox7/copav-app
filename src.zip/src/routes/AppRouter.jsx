import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

// Layouts
import AdminLayout from "../layouts/AdminLayout";
import UserLayout from "../layouts/UserLayout";

// Páginas Admin
import DashboardAdmin from "../pages/admin/DashboardAdmin";
import Arbitros from "../pages/admin/Arbitros";
import Partidos from "../pages/admin/Partidos";
import Torneos from "../pages/admin/Torneos";
import Reportes from "../pages/admin/Reportes";

// Páginas User
import DashboardUser from "../pages/user/DashboardUser";
import MisPartidos from "../pages/user/MisPartidos";
import Estadisticas from "../pages/user/Estadisticas";
import Perfil from "../pages/user/Perfil";

// Página de Login
import Login from "../pages/Login";

const AppRouter = () => {
  return (
    <Router>
      <Routes>

        {/* Página principal → redirige al login */}
        <Route path="/" element={<Navigate to="/login" replace />} />

        {/* Login */}
        <Route path="/login" element={<Login />} />

        {/* ADMIN */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route path="dashboard" element={<DashboardAdmin />} />
          <Route path="arbitros" element={<Arbitros />} />
          <Route path="partidos" element={<Partidos />} />
          <Route path="torneos" element={<Torneos />} />
          <Route path="reportes" element={<Reportes />} />
          <Route index element={<Navigate to="/admin/dashboard" replace />} />
        </Route>

        {/* USER */}
        <Route path="/user" element={<UserLayout />}>
          <Route path="dashboard" element={<DashboardUser />} />
          <Route path="mis-partidos" element={<MisPartidos />} />
          <Route path="estadisticas" element={<Estadisticas />} />
          <Route path="perfil" element={<Perfil />} />
          <Route index element={<Navigate to="/user/dashboard" replace />} />
        </Route>

        {/* Ruta no encontrada */}
        <Route path="*" element={<h1 className='p-8 text-center text-2xl font-semibold'>404 - Página no encontrada</h1>} />
      </Routes>
    </Router>
  );
};

export default AppRouter;
